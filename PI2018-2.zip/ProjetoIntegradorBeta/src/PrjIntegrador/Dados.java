/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PrjIntegrador;

/**
 *
 * @author Flamaryon Klever
 */
public class Dados {
    private String ip;
    private String data;
    private String hora;
    private String minuto;
    private String navegador;
    private String sistema;

    public Dados() {
    }

    public Dados(String ip, String data, String hora, String minuto, String navegador, String sistema) {
        this.ip = ip;
        this.data = data;
        this.hora = hora;
        this.minuto = minuto;
        this.navegador = navegador;
        this.sistema = sistema;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getMinuto() {
        return minuto;
    }

    public void setMinuto(String minuto) {
        this.minuto = minuto;
    }

    public String getNavegador() {
        return navegador;
    }

    public void setNavegador(String navegador) {
        this.navegador = navegador;
    }

    public String getSistema() {
        return sistema;
    }

    public void setSistema(String sistema) {
        this.sistema = sistema;
    }

    @Override
    public String toString() {
        return "Dados{" + "ip=" + ip + ", data=" + data + ", hora=" + hora + ", minuto=" + minuto + ", navegador=" + navegador + ", sistema=" + sistema + '}';
    }
}



    