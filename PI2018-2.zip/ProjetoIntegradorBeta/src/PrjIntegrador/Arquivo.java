
package PrjIntegrador;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Arquivo {

    public static ArrayList<Dados> lerArquivo(File dadosArquivo) {
        Dados x;
        ArrayList<Dados> lista = new ArrayList<>();
        String linhaDoArquivo;
        String[] dadoslog;
        try {
            Scanner leia = new Scanner(dadosArquivo);
            while (leia.hasNext()) {
                x = new Dados();
                linhaDoArquivo = leia.nextLine();
                dadoslog = linhaDoArquivo.split(";");
                x.setIp(dadoslog[0]);
                x.setData(dadoslog[1]);
                x.setHora(dadoslog[2]);
                x.setMinuto(dadoslog[3]);
                x.setNavegador(dadoslog[4]);
                lista.add(x);
            }
            return lista;
        } catch (FileNotFoundException e) {
            System.out.println("O arquivo especificado não foi encontrado.");
            return null;
        }
    }

}
