package ipcalcu;
public class Ipcalcu {
     static int[] ipprov;
    static int prefixo, hosts;
    static String classe, result, ipIncompleto, rede, broadcast, mascara;


    public boolean VerificaIP(String str) {
      
        String[] splitIP;
        
        splitIP = str.split("\\.");
        
        if(splitIP.length != 4 || splitIP[0].equals("0"))return false;

        for (String splitIP1 : splitIP) {
          
            if (splitIP1.equals("") || splitIP1.length() > 3) {
                return false;
            }
           
            for (int j = 0; j < splitIP1.length(); j++) {
                if (!Character.isDigit(splitIP1.charAt(j))) {
                    return false;
                }
            }
        }
        
        
        ipprov = new int[splitIP.length];
        
        for(int i = 0; i<splitIP.length; i++){
            if(Integer.parseInt(splitIP[i])<0 || Integer.parseInt(splitIP[i])>255)return false;
            ipprov[i] = Integer.parseInt(splitIP[i]);
        }
        return true;
       
        
    }
    
  
    public boolean VerificaPrefixo(String str) {
        
        if(str.equals("") || str.length()>2)return false;
  
        for(int i=0;i<str.length();i++)if(!Character.isDigit(str.charAt(i)))return false;
        int temp = Integer.parseInt(str);
        if(temp<1 || temp>32)return false;
        prefixo = temp;
        return true;
    }
    
    public String Retorno(){
        
        result = ""; 
        VerificaClasse();
        Saida();
        return result;
    }
    public void VerificaClasse() {
        int oct1 = ipprov[0];
        if(oct1<=127){
            classe = "A";
        }else if(oct1<=191){
            classe = "B";
        }else if(oct1<=223){
            classe = "C";
        }else if(oct1<=239){
            classe = "D";
        }else if(oct1<=255){
            classe = "E";
        }
    }
    
    public void Calcula(){
        int mask = 0, b = 0, c=0;
        int bitsOff = 32-prefixo;
        hosts = (int) Math.pow(2, bitsOff);
        
        int i=7;
        while(i>=bitsOff){
            mask+=Math.pow(2, i);
            i--;
        }
        
        do{
            c+=hosts;
            b=c-1;
        }while(b<ipprov[3]);
        
        ipIncompleto = ipprov[0]+"."+ipprov[1]+"."+ipprov[2]+".";
        rede = ipIncompleto+(b-hosts+1);
        broadcast = ipIncompleto+b;
        mascara = "255.255.255."+mask;
    }
    
    public void Saida(){
     
        if(classe.equals("C") && prefixo>=24 && prefixo<=31){
            Calcula();
            result ="\n            Projeto Integrador 2018\n"+"\nIP : "+ipIncompleto+ipprov[3]+"/"+prefixo+"\nRede : "+rede+"\nMáscara : "+mascara+"\nBroadcast : "+broadcast+"\nIP Classe "+classe+"\n\n";
            result+=Tabela();
            }
        else if(prefixo>=24 && prefixo<=31){
                Calcula();
                result ="\n            Projeto Integrador 2018\n"+"\nIP : "+ipIncompleto+ipprov[3]+"/"+prefixo+"\nRede : "+rede+"\nMáscara : "+mascara+"\nBroadcast : "+broadcast+"\nIP Classe "+classe+"\n\n";
            }
        else{
                result ="\n            Projeto Integrador 2018\n\n"+ "IP Classe "+classe+"\nIP: "+ipprov[0]+"."+ipprov[1]+"."+ipprov[2]+"."+ipprov[3]+"/"+prefixo;
            }
    }
    
    /**
     *Sub redes 
     
     */
    public String Tabela(){
        String temp="";
        int count = 1, octeto = 0, broadcastRede=hosts;
        do{
            if((octeto+1)==broadcastRede-1){
            temp+=count+": "+"Sub-rede "+ipIncompleto+octeto+"\tBroadcast: "+ipIncompleto+(broadcastRede-1)+"\n";    
            }else{
            temp+=count+": "+"Sub-rede "+ipIncompleto+octeto+"\tHost: "+ipIncompleto+(octeto+1)+" a "+(broadcastRede-2)+"\tBroadcast: "+ipIncompleto+(broadcastRede-1)+"\n";
            }
            broadcastRede+=hosts;
            octeto+=hosts;
            count++;
        }while(octeto<255);
     
        return temp;
    }
    }